#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
_____.___._______________  __.____ __________    _________   ___ ___    _____  .___ 
\__  |   |\_   _____/    |/ _|    |   \      \   \_   ___ \ /   |   \  /  _  \ |   |
 /   |   | |    __)_|      < |    |   /   |   \  /    \  //    ~    /  /_\  \|   |
 \____   | |        \    |  \|    |  /    |    \ \     \___\    Y    /    |    \   |
 / ______|/_______  /____|__ \______/\____|__  /  \______  /\___|_  /\____|__  /___|
 \/               \/        \/               \/          \/       \/         \/     
@author: Yekun Chai
@email: chaiyekun@baidu.com
@license: (C)Copyright Baidu NLP
@file: __init__.py
@time: 2022/01/10 11:16:59
@desc: None
'''

name="embedding4bert"

from embedding4bert.embedding4bert import *